.. _tests:

Running Tests
-------------

Download the test datasets
`kuka_gym_test <https://drive.google.com/open?id=154qMJHgUnzk0J_Hxmr2jCnV1ipS7o1D5>`__
and
`kuka_gym_dual_test <https://drive.google.com/open?id=15Fhqr4-kai4b8qQWiq2mEAWW5ZqH5qID>`__
and put it in ``srl_zoo/data/`` folder.

::

   ./run_tests.sh --all
